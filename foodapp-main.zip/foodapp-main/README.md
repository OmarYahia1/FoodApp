this project is done by android studio kotlin
